const User=require('../model/userModel')

//create user
const UserController=async(req,res)=>{
    //console.log(req.body);
    try{
        const Udata=await new User({
            name:req.body.name,
            email:req.body.email,
            city:req.body.city,
        })
      const data=await Udata.save()
     return res.status(201).json({
        success:true,
        message:"Data Added Successfully",
        data
    })

    }catch(error){
       return res.status(500).json({
            success:false,
            error
        })
    }

}

//get User

const GetUser=async(req,res)=>{
    try{

        const allData=await User.find()
        return res.status(200).json({
            success:true,
            message:"Data fetch Successfully",
            allData
        })

    }catch(error){
        return res.status(500).json({
            success:false,
            error
        }) 
    }

}

module.exports={
    UserController,
    GetUser
}
const express=require('express');
const { UserController, GetUser } = require('../controller/ApiController');
const Route=express.Router();

Route.post('/user',UserController)
Route.get('/all-user',GetUser)




module.exports=Route